//
//  AppTheme.swift
//  MovieApp-TakeHomeProject
//
//  Created by Ikmal Azman on 20/05/2022.
//

import Foundation
import UIKit

struct AppTheme {
    static let darkishPink = UIColor(named: "darkishPink")
}
