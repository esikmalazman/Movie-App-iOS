//
//  Language.swift
//  MovieApp-TakeHomeProject
//
//  Created by Ikmal Azman on 17/05/2022.
//

import Foundation

struct Language : Decodable {
    let name : String
}
