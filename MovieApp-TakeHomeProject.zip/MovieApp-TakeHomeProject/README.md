## App User Flow
<img src="https://user-images.githubusercontent.com/59039044/169497174-5b999926-5c00-4e9f-ba1e-924633d48341.png" width="500">

## App Screenshots

| Home | Movie Details | Movie Booking |
| ---- | ------ | ------------- | 
|<img src="https://user-images.githubusercontent.com/59039044/169498183-24dd05ee-7b5e-493d-8e9f-2ed7516cbde2.png" width="200">| <img src="https://user-images.githubusercontent.com/59039044/169498217-8e73d300-2943-4ccf-9ac9-696255aa70dd.png" width="200"> | <img src="https://user-images.githubusercontent.com/59039044/169498241-aa013c20-9371-4304-a928-d0fa10cbd132.png" width="200"> |


## App Demo


<img src="https://user-images.githubusercontent.com/59039044/169497383-a2d6aeef-c703-400b-b746-8fb23e85bd8a.mov" width="400">



